﻿// See https://aka.ms/new-console-template for more information

using DapperTutorial.Presentation.UI;

// ManageDepartment manageDepartment = new ManageDepartment();
// manageDepartment.Run();

ManageEmployee manageEmployee = new ManageEmployee();
manageEmployee.Run();