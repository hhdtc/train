﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationCore.Model.Response
{
    public class CategoryResponseModel
    {
        public int Id { get; set; }
        public string CategoryName { get; set; } = string.Empty;
    }
}
